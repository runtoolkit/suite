# Codespaces ile runtoolkit konsolidasyonu

## 1. Secret tanımla (token asla repo'ya girmez)
GitHub → sağ üst profil → **Settings** → **Codespaces** → **Secrets** → **New secret**
- Name: `RT_CONSOLIDATE_TOKEN`
- Value: token'ın
- Repository access: bu script'i barındıracağın repo (örn. kendi private "scratch" reponu, `runtoolkit/suite` değil — o daha oluşmadı)

## 2. Bu klasörü bir repoya koy
`.devcontainer/` klasörünü (devcontainer.json + consolidate.sh) herhangi bir GitHub reponun köküne koy, commit+push et.

## 3. Codespace aç
O reponun sayfasında **Code → Codespaces → Create codespace on main**.
Codespace açılırken secret otomatik `GITHUB_TOKEN` env değişkeni olarak enjekte edilir.

## 4. Çalıştır
Codespace terminali açılınca:
```
bash .devcontainer/consolidate.sh
```
Script sana bir analiz raporu gösterecek, "evet" yazıp onaylayınca devam edecek.

## 5. Bitince
- Codespace'i sil (Code → Codespaces → ... → Delete)
- `RT_CONSOLIDATE_TOKEN` secret'ını GitHub'dan sil
- Token'ı GitHub Settings → Developer settings → Personal access tokens'tan **revoke et**
