
# macroEngine (v26.3.3)

**macroEngine** is a macro/module framework datapack for Minecraft Java Edition, providing a large library of reusable command-based systems (math, string, NBT, geo, permissions, UUID cache, hooks, rate limiting, and more) plus a multi-source text/value input system (dialogs, books, signs, lecterns, name tags, command block minecarts).

> Owner: [runtoolkit](https://github.com/runtoolkit)
> Minecraft: **26.3-rc-1** (`pack_format` / `min_format`–`max_format` **121**)
> License: MIT
> Namespace: `macroengine`

---

## Features

- **API layer** (`api/`) — stable public entry points: `cmd`, `cb` (callback queue), `color`, `dialog`, `gamerule`, `interaction`, `item`, `macro`, `perm`, `title`, `toggle`, `trigger`, `wand`
- **Systems layer** (`systems/`) — internal utility modules: `math`, `string`, `nbt`, `logic`, `geo`, `flag`, `hook`, `log`, `rate_limit`, `sound`, `uuid`, `color`
- **Input system** (`input/`) — capture player-provided values via writable book, sign, lectern, name tag, dialog, or command block minecart, with shared validation (`input/validate`) for int/float/bool/tag-safe strings
- **Toggle system** — per-module runtime enable/disable for `cb`, `perm`, `geo`, `wand`, `interaction`, `hook`, and `experimental` features
- **Rate limiting** — global, per-player, and per-channel request throttling
- **Hook system** — bind functions to fire on events such as block break, dimension change, and advancement grant
- **Item modifiers** (`item_modifier/`) — reusable `item_modifier` definitions for enchanting, glint, lore, tooltip, and rename operations
- **Advancement-driven triggers** (`advancement/`) — core, hidden, and system advancements used to drive internal logic and hooks
- **Experimental namespace** — gated behind `toggle/experimental`, for features not yet considered stable
- **Chat channels** (`chat_type/`, `api/chat/`) — styled message channels (`admin_broadcast`, `gate_log`, `rate_limit_notice`) with a tellraw-based sender routed through `systems/rate_limit`. Note: vanilla `chat_type` only auto-applies to signed player chat, not function-issued messages — `api/chat/send` mimics the registered style rather than assigning the real chat_type.
- **gate_sanctuary biome** (`worldgen/`, `api/world/goto_sanctuary`) — a no-spawn, no-precipitation biome intended as an admin/testing area, with a sparse `sanctuary_marker` surface feature. Requires a world restart after first adding the pack (worldgen does not reload with `/reload`).
- **Jukebox discs** (`jukebox_song/`, `api/jukebox/give`) — custom `jukebox_song` registry entries (`gate_alert`, `sanctuary_ambient`) reusing vanilla sound events, given via `api/jukebox/give` as a `jukebox_playable`-bound `music_disc_11` item.

---

## Requirements

- Minecraft Java Edition **26.3-rc-1**
- Datapack `min_format`/`max_format`: **121**

---

## Installation

1. Place the datapack folder in your world's `datapacks/` directory (or load it via a server-side pack source).
2. Run `/reload` or restart the server.
3. macroEngine initializes automatically via `#macroengine:events/on_load`.

To manually check load state or configuration, see `data/macroengine/function/config/` and `data/macroengine/function/debug/`.

---

## Usage

Most functionality is exposed through the `api/` namespace, e.g.:

```mcfunction
function macroengine:api/cmd/actionbar
function macroengine:api/dialog/show
function macroengine:api/perm/grant
function macroengine:api/wand/give
```

Internal systems under `systems/` are used by API functions and are not intended to be called directly by end users, though they remain accessible for advanced/custom integrations.

---

## Notes

- This is the 26.3-rc-1 line of macroEngine, part of the `runtoolkit/suite` monorepo (`packs/macroEngine-Datapack-v26.3.3`).
- A parallel `packs/macroEngine-Datapack-1.21.2` build exists for older-version support.
- Experimental features are opt-in via `api/toggle/experimental/true` and are not guaranteed stable between versions.

---

## License

MIT — see the repository [LICENSE](https://github.com/runtoolkit/suite/blob/main/LICENSE).
